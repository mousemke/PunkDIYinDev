/**
 * Do it yourself
 *
 * These problems wont solve themselves and are too specific for
 * broader solutions
 *
 * @param  {human, probably}        you
 *
 * @return {object}                 solution
 */
var diy = function( you, challenge )
{
    return you.solveProblems( challenge );
};